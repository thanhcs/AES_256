/**
 * Created by thanhnguyencs on 6/29/15.
 */
public class DataCryptoECB extends DataCrypto {

    public DataCryptoECB(String key, String length) {
        super(key, length);
    }
}
